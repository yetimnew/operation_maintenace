
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officenumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'DPPA','AA','1212121212','1212121212','fffffffffffffffffffff',1,NULL,'2019-10-24 02:13:51','2019-10-24 02:13:51');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `driver_truck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver_truck` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `driverid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_recived` date NOT NULL,
  `date_detach` date DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `driver_truck_driverid_index` (`driverid`),
  KEY `driver_truck_plate_index` (`plate`),
  CONSTRAINT `driver_truck_driverid_foreign` FOREIGN KEY (`driverid`) REFERENCES `drivers` (`driverid`),
  CONSTRAINT `driver_truck_plate_foreign` FOREIGN KEY (`plate`) REFERENCES `trucks` (`plate`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `driver_truck` WRITE;
/*!40000 ALTER TABLE `driver_truck` DISABLE KEYS */;
INSERT INTO `driver_truck` VALUES (2,'12547','1000','2019-10-28',NULL,NULL,1,NULL,'2019-10-28 12:24:16','2019-10-28 12:24:16'),(3,'1254','12547','2019-10-28',NULL,NULL,1,NULL,'2019-11-04 10:05:37','2019-11-04 10:05:37');
/*!40000 ALTER TABLE `driver_truck` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drivers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `driverid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT 0,
  `birthdate` date NOT NULL,
  `zone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woreda` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kebele` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `housenumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hireddate` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drivers_driverid_index` (`driverid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES (5,'12547','bekele gerba',1,'2019-10-02','12','12','12','12','1212121212','2020-01-03',1,NULL,'2019-10-28 12:23:51','2019-11-04 03:26:26'),(6,'1254','bekele melagnaw',1,'2019-11-05','12','12','121','12','1212121212','2019-11-05',0,NULL,'2019-11-01 12:29:23','2019-11-04 04:31:25'),(7,'1254','Yetimnesht Tadesse',1,'2019-11-05','sss','qw','12','12','1212121212','2019-11-05',0,NULL,'2019-11-03 04:40:35','2019-11-04 04:19:41');
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (65,'2014_10_12_000000_create_users_table',1),(66,'2014_10_12_100000_create_password_resets_table',1),(67,'2019_04_26_144309_create_trucks_table',1),(68,'2019_05_01_153410_create_vehecletypes_table',1),(69,'2019_05_04_094633_create_drivers_table',1),(70,'2019_05_04_131508_create_operations_table',1),(71,'2019_05_04_151405_create_customers_table',1),(72,'2019_05_04_152106_create_regions_table',1),(73,'2019_05_05_080818_create_statuses_table',1),(74,'2019_05_05_083302_create_statustypes_table',1),(75,'2019_05_07_183529_create_performances_table',1),(76,'2019_05_08_145526_create_driver_truck_table',1),(77,'2019_05_09_084348_create_places_table',1),(78,'2019_06_04_071612_create_performance_by_model_report_views',1),(79,'2019_10_08_072533_create_permission_tables',1),(80,'2019_10_12_151817_create_profiles_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (60,'App\\User',22),(60,'App\\User',23),(60,'App\\User',26),(61,'App\\User',22),(61,'App\\User',23),(61,'App\\User',26),(62,'App\\User',22),(62,'App\\User',23),(63,'App\\User',22),(63,'App\\User',23),(64,'App\\User',22),(64,'App\\User',23),(65,'App\\User',22),(65,'App\\User',23),(66,'App\\User',22),(67,'App\\User',22),(68,'App\\User',22),(69,'App\\User',22),(69,'App\\User',26),(70,'App\\User',22),(71,'App\\User',22),(72,'App\\User',22),(73,'App\\User',22),(74,'App\\User',22),(75,'App\\User',22),(76,'App\\User',22),(77,'App\\User',22),(78,'App\\User',22),(79,'App\\User',22),(80,'App\\User',22),(81,'App\\User',22),(82,'App\\User',22),(83,'App\\User',22),(84,'App\\User',22),(85,'App\\User',22),(86,'App\\User',22),(87,'App\\User',22),(88,'App\\User',22),(89,'App\\User',22),(90,'App\\User',22),(91,'App\\User',22),(91,'App\\User',26),(92,'App\\User',22),(93,'App\\User',22),(94,'App\\User',22),(95,'App\\User',22),(96,'App\\User',22),(97,'App\\User',22),(97,'App\\User',26),(98,'App\\User',22),(99,'App\\User',22),(100,'App\\User',22),(101,'App\\User',22),(101,'App\\User',26),(102,'App\\User',22),(102,'App\\User',26),(103,'App\\User',22),(103,'App\\User',26);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (11,'App\\User',18),(11,'App\\User',20),(11,'App\\User',21),(11,'App\\User',22),(11,'App\\User',30),(11,'App\\User',33),(12,'App\\User',19),(12,'App\\User',23),(12,'App\\User',26),(12,'App\\User',31),(12,'App\\User',32);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `operationid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `startdate` date NOT NULL,
  `region_id` int(10) unsigned DEFAULT NULL,
  `volume` double(12,4) NOT NULL,
  `cargotype` tinyint(1) NOT NULL DEFAULT 1,
  `km` double(12,4) DEFAULT NULL,
  `tariff` double(12,4) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `closed` tinyint(1) NOT NULL DEFAULT 1,
  `enddate` date DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `operations` WRITE;
/*!40000 ALTER TABLE `operations` DISABLE KEYS */;
INSERT INTO `operations` VALUES (1,'12547',1,'2019-10-24',1,1000.0000,0,12587.0000,2.7500,1,1,NULL,NULL,NULL,'2019-10-24 02:23:20','2019-10-24 02:23:20'),(2,'DPPA-12',1,'2019-11-04',1,1000.0000,1,12547.0000,3.2500,1,1,NULL,NULL,NULL,'2019-11-04 09:52:04','2019-11-04 09:52:04');
/*!40000 ALTER TABLE `operations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `performance_by_model_report_views`;
/*!50001 DROP VIEW IF EXISTS `performance_by_model_report_views`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `performance_by_model_report_views` (
  `vehecletype_id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `no` tinyint NOT NULL,
  `Trip` tinyint NOT NULL,
  `dwc` tinyint NOT NULL,
  `dwoc` tinyint NOT NULL,
  `Tone` tinyint NOT NULL,
  `KM` tinyint NOT NULL,
  `Tonek` tinyint NOT NULL,
  `fl` tinyint NOT NULL,
  `fib` tinyint NOT NULL,
  `Perdium` tinyint NOT NULL,
  `other` tinyint NOT NULL,
  `totla` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `performances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `performances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `LoadType` tinyint(1) NOT NULL,
  `FOnumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` int(11) NOT NULL,
  `driver_truck_id` int(11) NOT NULL,
  `DateDispach` datetime NOT NULL,
  `orgion_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `DistanceWCargo` double(12,4) NOT NULL,
  `tonkm` double(20,4) NOT NULL DEFAULT 0.0000,
  `DistanceWOCargo` double(12,4) DEFAULT NULL,
  `CargoVolumMT` double(12,4) DEFAULT NULL,
  `fuelInLitter` double(12,4) DEFAULT NULL,
  `fuelInBirr` double(12,4) DEFAULT NULL,
  `perdiem` double(12,4) DEFAULT NULL,
  `workOnGoing` double(12,4) DEFAULT NULL,
  `other` double(12,4) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `satus` tinyint(1) NOT NULL DEFAULT 1,
  `is_returned` tinyint(1) NOT NULL DEFAULT 0,
  `returned_date` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performances_operation_id_index` (`operation_id`),
  KEY `performances_driver_truck_id_index` (`driver_truck_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `performances` WRITE;
/*!40000 ALTER TABLE `performances` DISABLE KEYS */;
INSERT INTO `performances` VALUES (5,1,'12547',1,2,'2019-11-04 14:03:48',1,2,125.0000,3625.0000,125.0000,29.0000,125.0000,125.0000,125.0000,125.0000,125.0000,'the commnet comes here',1,0,NULL,22,NULL,'2019-11-04 08:04:32','2019-11-04 08:04:32'),(6,0,'1254A',2,2,'2019-11-04 16:00:52',1,1,125.0000,5000.0000,125.0000,40.0000,149.0000,1580.0000,150.0000,125.0000,125.0000,'sssssssssss',1,1,'2019-11-04 16:44:43',22,NULL,'2019-11-04 10:42:13','2019-11-04 10:44:51');
/*!40000 ALTER TABLE `performances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (60,'truck create','web','2019-10-28 08:14:12','2019-10-28 08:14:12'),(61,'truck edit','web','2019-10-28 08:14:12','2019-10-28 08:14:12'),(62,'truck delete','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(63,'truck view','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(64,'truck_model create','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(65,'truck_model edit','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(66,'truck_model delete','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(67,'truck_model view','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(68,'driver create','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(69,'driver edit','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(70,'driver delete','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(71,'driver view','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(72,'operation create','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(73,'operation edit','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(74,'operation delete','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(75,'operation view','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(76,'operation_place create','web','2019-10-28 08:14:13','2019-10-28 08:14:13'),(77,'operation_place edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(78,'operation_place delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(79,'operation_place view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(80,'operation_region create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(81,'operation_region edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(82,'operation_region delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(83,'operation_region view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(84,'customer create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(85,'customer edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(86,'customer delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(87,'customer view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(88,'performance create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(89,'performance edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(90,'performance delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(91,'performance view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(92,'status create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(93,'status edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(94,'status delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(95,'status view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(96,'status_type create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(97,'status_type edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(98,'status_type delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(99,'status_type view','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(100,'truck_driver create','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(101,'truck_driver edit','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(102,'truck_driver delete','web','2019-10-28 08:14:14','2019-10-28 08:14:14'),(103,'truck_driver view','web','2019-10-28 08:14:15','2019-10-28 08:14:15');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `places` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region_id` int(11) NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `places_region_id_index` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (1,'Addis abeba',1,'ssssssssssssssssssssss',1,NULL,'2019-10-24 02:12:51','2019-10-24 02:12:51'),(2,'Nazrath',1,'sssssssssssssssssss',1,NULL,'2019-10-24 02:13:12','2019-10-24 02:13:12');
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `about` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profiles_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES (1,'uploads/images/1571896386447815202_247854.jpg',1,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-24 02:07:39','2019-10-24 02:53:06'),(2,'uploads/images/1571896504426037194_38960.jpg',2,NULL,NULL,'2019-10-24 02:54:18','2019-10-24 02:55:04'),(3,'uploads/avatar.jpg',18,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-28 08:21:02','2019-10-28 08:21:02'),(4,'uploads/images/1572605403447815202_247854.jpg',22,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-28 15:33:27','2019-11-01 07:50:03'),(5,'uploads/images/1572338473447812590_265060.jpg',24,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-29 05:20:07','2019-10-29 05:41:13'),(6,'uploads/avatar.jpg',25,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-29 06:00:03','2019-10-29 06:00:03'),(7,'uploads/images/1572351562447804617_250497.jpg',26,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-10-29 06:10:35','2019-10-29 09:19:22');
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES (1,'central','sssssssssssssssssss',1,NULL,'2019-10-24 02:12:22','2019-10-24 02:12:22');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (11,'admin','web','2019-10-28 08:10:06','2019-10-28 08:10:06'),(12,'user','web','2019-10-28 08:10:06','2019-10-28 08:10:06');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoid` int(11) NOT NULL DEFAULT 1,
  `statustype_id` int(11) DEFAULT NULL,
  `plate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registerddate` date NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `statustypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statustypes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusgroup` tinyint(1) NOT NULL DEFAULT 0,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `statustypes` WRITE;
/*!40000 ALTER TABLE `statustypes` DISABLE KEYS */;
INSERT INTO `statustypes` VALUES (1,'On Road',1,'sssssssssssssss',1,NULL,'2019-11-04 11:08:25','2019-11-04 11:17:06'),(2,'Raod call',0,'the comment',1,NULL,'2019-11-04 11:18:51','2019-11-04 11:18:51'),(3,'Waiting load/Quee',0,'sssssssssss',1,NULL,'2019-11-04 11:20:15','2019-11-04 11:20:15'),(4,'Unloading',0,'ssssssss',1,NULL,'2019-11-04 11:20:31','2019-11-04 11:20:31');
/*!40000 ALTER TABLE `statustypes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `trucks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trucks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehecletype_id` int(10) unsigned NOT NULL,
  `chasisNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engineNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tyreSyze` int(11) DEFAULT NULL,
  `serviceIntervalKM` double(12,4) DEFAULT NULL,
  `purchasePrice` double(12,4) DEFAULT NULL,
  `productionDate` date DEFAULT NULL,
  `serviceStartDate` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trucks_plate_index` (`plate`),
  KEY `trucks_vehecletype_id_index` (`vehecletype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `trucks` WRITE;
/*!40000 ALTER TABLE `trucks` DISABLE KEYS */;
INSERT INTO `trucks` VALUES (1,'1000',1,'12','12',12,12.0000,12.0000,NULL,NULL,1,NULL,'2019-10-24 03:22:39','2019-11-04 05:25:03'),(2,'12547',1,'1254','1254',12,12.0000,12.0000,'0012-12-12','2019-10-30',1,NULL,'2019-10-30 08:13:18','2019-11-04 04:32:02');
/*!40000 ALTER TABLE `trucks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (22,'Yetimesht Tadesse','yetimnew@gmail.com',NULL,'$2y$10$CLweyWGBYwlT1BTsK6eae.mzkn9yP.6YS.Bs6Cc39JODtf7oUysXW',1,1,NULL,'2019-10-28 15:33:26','2019-11-01 07:50:03'),(26,'Edited','ed@gmail.com',NULL,'$2y$10$LWGkOuaCKVh0KWYykcU1wuaf0ivPnZKl.WpQeykM0GifVnAZjUphK',0,0,'kVIXThXMLHbRzsUHy3EqHDScVa9pD1PFrx3f4gnWpeXaqDpHhvfkIcKzGHO0','2019-10-29 06:10:35','2019-10-29 10:00:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vehecletypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehecletypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productiondate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vehecletypes` WRITE;
/*!40000 ALTER TABLE `vehecletypes` DISABLE KEYS */;
INSERT INTO `vehecletypes` VALUES (1,'Old','ss','2019-10-24','ssssssssssssss',1,NULL,'2019-10-24 03:21:22','2019-10-24 03:21:22');
/*!40000 ALTER TABLE `vehecletypes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50001 DROP TABLE IF EXISTS `performance_by_model_report_views`*/;
/*!50001 DROP VIEW IF EXISTS `performance_by_model_report_views`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `performance_by_model_report_views` AS (select `trucks`.`vehecletype_id` AS `vehecletype_id`,`vehecletypes`.`name` AS `name`,count(distinct `trucks`.`plate`) AS `no`,count(`performances`.`FOnumber`) AS `Trip`,sum(`performances`.`DistanceWCargo`) AS `dwc`,sum(`performances`.`DistanceWOCargo`) AS `dwoc`,sum(`performances`.`CargoVolumMT`) AS `Tone`,sum(`performances`.`DistanceWCargo`) + sum(`performances`.`DistanceWOCargo`) AS `KM`,sum(`performances`.`CargoVolumMT` * `performances`.`DistanceWCargo`) AS `Tonek`,sum(`performances`.`fuelInLitter`) AS `fl`,sum(`performances`.`fuelInBirr`) AS `fib`,sum(`performances`.`perdiem`) AS `Perdium`,sum(`performances`.`other`) AS `other`,sum(`performances`.`fuelInBirr`) + sum(`performances`.`perdiem`) + sum(`performances`.`other`) AS `totla` from ((`trucks` join `vehecletypes` on(`vehecletypes`.`id` = `trucks`.`vehecletype_id`)) left join `performances` on(`trucks`.`id` = `performances`.`driver_truck_id`)) group by `vehecletypes`.`id` order by `performances`.`FOnumber` desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

